﻿///TESTING AREA///

/*using static System.Console;
namespace playground
    {
    class Programm
        {
        static void Main(string[] args)
            {

            string[][] mapping ={
                new string[] { "||||||", "||||||", "||||||" }, //[0][0],[0][1],[0][2]
                new string[] { "||||||", "none |", "||||||" }, //[1][0],[1][1],[1][2]
                new string[] { "|none|", "orc  |", "none |" }, //[2][0],[2][1],[2][2]
                new string[] { "|none|", "foes |", "store|" }, //[3][0],[3][1],[3][2]
                new string[] { "|none|", "start|", "rats |" }, //[4][0],[4][1],[4][2]
                new string[] { "|none|", "gems |", "none |" }, //[5][0],[5][1],[5][2]
                new string[] { "||||||", "none |", "||||||" }, //[6][0],[6][1],[6][2]
                new string[] { "||||||", "||||||", "||||||" }  //[7][0],[7][1],[7][2]
                };
            WriteLine("Testcenter:\n\n");
            for(int i = 0;i < 8;i++)
                {
                WriteLine(mapping[i][0] + mapping[i][1] + mapping[i][2]);
                }

            }
        }
    }
*/
