﻿///THIS IS STILL WORK IN PROGRESS!!!!!
//TODO: WIP

namespace RPGOne
    {
    internal class Quest
        {
        //        import Character


        //class Quest: # Missing XP!!!
        //    def __init__(self, name, desc, pos_x, pos_y, npcs, enemies, items, weapons, armors, ender):
        //        self.name = name
        //        self.desc = desc
        //        self.pos_x = pos_x
        //        self.pos_y = pos_y
        //        self.npcs = npcs
        //        self.enemies = enemies
        //        self.items = items
        //        self.armors = armors
        //        self.weapons = weapons
        //        self.ender = ender # the name of the corresponding ending method??
        //        self.complete = False

        //    def status(self):
        //        print(self.name)
        //        print(self.desc)
        //        print("QUEST X: " + str(self.pos_x))
        //        print("QUEST Y: " + str(self.pos_y))

        //        if self.ender.quest_ended is False:
        //            self.uncompleted()
        //        else:
        //            self.completed()

        //        print("YOU SEE: ")
        //        for npc in self.npcs:
        //            print(npc.name)
        //        for enemy in self.enemies:
        //            print(enemy.name)
        //        for item in self.items:
        //            print(item.name)
        //        for weapon in self.weapons:
        //            print(weapon.name)
        //        for armor in self.armors:
        //            print(armor.name)

        //    def uncompleted(self):
        //        print("QUEST STARTS HERE AND IS NOT COMPLETED")

        //    def completed(self):
        //        print("QUEST IS COMPLETED")

        //'''should I split it here into another file?'''
        //class Quest_Ender: # Missing XP!!!
        //    def __init__(self, name, desc, pos_x, pos_y, npcs, enemies, items, weapons, armors):
        //        self.name = name
        //        self.desc = desc
        //        self.pos_x = pos_x
        //        self.pos_y = pos_y
        //        self.npcs = npcs
        //        self.enemies = enemies
        //        self.items = items
        //        self.weapons = weapons
        //        self.armors = armors
        //        self.quest_ended = False

        //    def status(self):
        //        print("YOU SEE: ")
        //        for npc in self.npcs:
        //            print(npc.name)
        //        for enemy in self.enemies:
        //            print(enemy.name)
        //        for item in self.items:
        //            print(item.name)
        //        for weapon in self.weapons:
        //            print(weapon.name)
        //        for armor in self.armors:
        //            print(armor.name)
        //        if len(self.enemies) == 0:
        //            print("PLAYER HAS COMPLETED QUEST")
        //            self.quest_ended = True


        //# QUEST ENDERS name,desc,pos_x,pos_y,npcs,enemies,items,weapons,armors
        //quest_1_ender = Quest_Ender("QUEST 1 ENDER","THIS ENDS QUEST 1",3,0, [], [Character.orc_peon], [], [], [])

        //# QUESTS  name, desc, pos_x, pos_y, npcs, enemies, items, weapons, armors, ender
        //quest_1 = Quest("QUEST 1", "THIS OS QUEST ONE", 2, 0,[],[],[],[],[],quest_1_ender)

        }
    }
